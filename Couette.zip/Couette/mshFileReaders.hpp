#pragma once
#include <vector>
#include <tuple>
#include "gridclasses.hpp"

std::pair<std::vector<Boundary>, std::vector<std::tuple<double, double, double>>> pointsAndBoundsFromMshFile() {

}