#include "testing_functions.hpp"
#include "FractionalStepSim.hpp"

int main() {
	run_frac_step_test();
	//run_tests();
	return 0;
}